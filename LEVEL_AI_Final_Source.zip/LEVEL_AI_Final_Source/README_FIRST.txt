
LEVEL AI — FINAL SOURCE PACKAGE
================================

This is the consolidated source project for LEVEL AI. It is NOT a compiled APK,
and the backend is NOT deployed online yet.

WHAT IS INCLUDED
- Android Studio project (Kotlin WebView wrapper)
- App interface (HTML/CSS/JavaScript)
- Node.js backend starter
- Chat endpoint using the official Google GenAI SDK
- Image endpoint scaffold (provider/model support must be configured and tested)
- Free-plan limits in the interface: 20 messages per chat and 5 image requests per day
- Setup instructions

IMPORTANT
1. A ZIP file is source code, not an installable Android app.
2. To make an APK, open the android/ folder in Android Studio and build it.
3. To make AI work online, deploy backend/ to a hosting provider and set its environment
   variables. Free hosting plans can sleep, have quotas, or change.
4. Google AI/API services may have quotas or charges. Check current pricing before use.
5. Never put an API key in the Android app or share it in chat. Keep it on the backend.
6. Because the project owner is under 18, a parent/guardian should handle accounts,
   API keys, hosting, billing, privacy, and publishing.

QUICK START
- Backend: see backend/README.md
- Android APK: see android/README.md
- App preview: open app/index.html in a browser

This package is a development starter, not a finished or tested production release.
