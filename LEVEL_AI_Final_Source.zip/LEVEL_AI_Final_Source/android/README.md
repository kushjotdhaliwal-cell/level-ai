# Build the Android APK

This requires a computer with Android Studio. It cannot be compiled directly on a Samsung phone using this project alone.

1. Open the `android/` folder in Android Studio.
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

Note: copy the contents of the `app/` web folder into `android/app/src/main/assets/` before building (index.html, style.css, app.js). Then edit `API_BASE` in app.js after the backend is deployed. The included assets index is only a placeholder.
